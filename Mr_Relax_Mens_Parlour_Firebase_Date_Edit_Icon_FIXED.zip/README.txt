Mr Relax Men's Parlour

Firebase-connected Android project with latest Date/Edit/Icon fixes.
- Cloud data sync via Firebase Authentication + Firestore
- Date displayed as DD/MM/YYYY
- New entry amount fields start blank (no prefilled 0)
- Existing Mr Relax logo retained as app icon
- Existing staff, reports, history, edit entry and hisaab features retained
