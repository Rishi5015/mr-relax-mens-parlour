# Mr Relax Men's Parlour App — Ready Project

This package contains:
- web_app/: responsive working app
- android_project/: Android Studio project that opens the same app as a native APK shell
- logo.jpg: supplied Mr Relax logo

Calculation:
Daily Earning = (Total Work × 50%) − Today's Expense
Running Pending = Previous Pending + Today's Earning
Hisaab Clear = saves the cleared amount in history and resets pending to ₹0.

Default staff:
Bittu Sharma, Deepak Sharma, Hasib, Salim, Faried, Rohit, X

The current build saves data locally and includes Export/Import backup.
Firebase/cloud sync is not connected because Firebase project configuration was not supplied.
