# Mr Relax Men's Parlour — Secure Firebase Build

Features included:
- Firebase Email/Password login for the same account on multiple phones.
- Shared Firestore document with real-time sync.
- 4-digit device MPIN lock stored locally on each phone.
- Amount and expense inputs start blank.
- Date defaults to today and can be selected/edited; display format DD/MM/YYYY.
- Mr Relax logo used in the app/PWA.
- Entry editing supported from staff daily history.

## Firebase setup (important)

1. Firebase Console → Authentication → Sign-in method → enable **Email/Password**.
2. Firebase Console → Authentication → Users → **Add user**.
   Create ONE owner login email + password. Use the SAME email/password on every phone.
3. Firebase Console → Firestore Database → Rules → paste the contents of `firestore.rules` and Publish.
4. If the Firestore database is empty, log in once on the first phone. The app creates `parlour/main` and stores the authenticated Firebase UID as `ownerUid`.
5. Log in on other phones with the SAME Firebase email/password. They receive the same Firebase UID and therefore can read/write the same parlour data.

Security rule behavior:
- Unauthenticated users cannot read or write Firestore.
- Only the Firebase account that owns `parlour/main` can read/write it.
- The ownerUid cannot be changed by an update.
- All other Firestore paths are denied by default.

Do NOT use the old rule `allow read, write: if request.auth != null;` for the production app.

Note: the 4-digit MPIN is device-local. It is separate from the Firebase account password, so each phone can have its own MPIN.
