// Firebase configuration for Mr Relax Men's Parlour.
// This configuration is for the Firebase project linked to the Android app.
window.MR_RELAX_FIREBASE_CONFIG = {
  apiKey: "AIzaSyBsEzSd-b6Q9CIXqpSCw0rgzm8WnYyRSPA",
  authDomain: "mr-relax.firebaseapp.com",
  projectId: "mr-relax",
  storageBucket: "mr-relax.firebasestorage.app",
  appId: "1:1025086066585:android:2b9bcff190a87bc859cd08"
};
