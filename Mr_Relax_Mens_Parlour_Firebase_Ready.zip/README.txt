# Mr Relax Men's Parlour App — Firebase Connected Build

Included:
- web_app/: responsive app
- android_project/: Android Studio project with google-services.json and Firebase-ready WebView
- logo.jpg: Mr Relax logo

Calculation:
Daily Earning = (Total Work × 50%) − Today's Expense
Running Pending = Previous Pending + Today's Earning
Hisaab Clear = saves the cleared amount in history and resets pending to ₹0.

Firebase project is configured for package com.mrrelax.parlour. The app uses Firebase Authentication (anonymous) + Cloud Firestore for cloud sync.

IMPORTANT: In Firebase Console, enable Authentication > Sign-in method > Anonymous, and create a Firestore Database. Recommended Firestore rule:
allow read, write: if request.auth != null;

After enabling those two items, build/install the APK. The app will sync the shared parlour data across phones signed into the same Firebase project.
