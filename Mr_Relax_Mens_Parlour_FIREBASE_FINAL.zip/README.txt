Mr Relax Men's Parlour — FINAL Firebase/Entry Fix

This package contains the Android project with:
- Firebase Authentication + Firestore cloud sync.
- Firebase cloud data is restored after uninstall/reinstall when Anonymous Authentication
  is enabled and Firestore rules allow authenticated read/write.
- Date display/input: DD/MM/YYYY.
- New Total Work and Expense fields start BLANK (not 0).
- 50% Staff Share calculates automatically from Total Work.
- Today's Earning calculates automatically as 50% Share minus Expense (minimum 0).
- Existing Mr Relax logo/app icon retained unchanged.
- Existing staff, reports, history, edit-entry and hisaab features retained.

IMPORTANT FOR THE EXISTING GITHUB WORKFLOW:
The workflow currently runs `unzip -q *.zip -d source`, which selects the first ZIP
alphabetically. This final package is intentionally named with `000_` so it is selected
before the older ZIP files still in the repository.


FINAL FIREBASE FIX
- Android WebView now serves app assets through WebViewAssetLoader (https://appassets.androidplatform.net/assets/) instead of file://, which avoids file-origin Firebase issues.
- Firebase Anonymous Auth + Firestore cloud save is required for cloud persistence.
- Entry amount fields start blank; date uses DD/MM/YYYY display with date picker; existing entries can be edited.
