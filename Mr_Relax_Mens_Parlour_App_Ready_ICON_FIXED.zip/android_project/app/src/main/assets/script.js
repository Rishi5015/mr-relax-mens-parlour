const KEY="mrrelax_v1";
const defaultStaff=["Bittu Sharma","Deepak Sharma","Hasib","Salim","Faried","Rohit","X"];
let db=JSON.parse(localStorage.getItem(KEY)||"null")||{staff:defaultStaff.map((name,i)=>({id:i+1,name,active:true})),entries:[],clears:[],expenses:[]};
function save(){localStorage.setItem(KEY,JSON.stringify(db))}
function money(n){return "₹ "+Number(n||0).toLocaleString("en-IN")}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function today(){return new Date().toISOString().slice(0,10)}
function fmt(d){return new Date(d+"T00:00:00").toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"})}
function staffById(id){return db.staff.find(s=>s.id==id)}
function staffBalance(id){return db.entries.filter(e=>e.staffId==id).reduce((a,e)=>a+e.earning,0)-db.clears.filter(c=>c.staffId==id).reduce((a,c)=>a+c.amount,0)}
function staffWork(id){return db.entries.filter(e=>e.staffId==id).reduce((a,e)=>a+e.work,0)}
function staffShare(id){return db.entries.filter(e=>e.staffId==id).reduce((a,e)=>a+e.share,0)}
function totalExpense(id){return db.entries.filter(e=>e.staffId==id).reduce((a,e)=>a+e.expense,0)}
function toast(t){let x=document.createElement("div");x.className="toast";x.textContent=t;document.body.appendChild(x);setTimeout(()=>x.remove(),1800)}
function setScreen(s){document.querySelectorAll(".bottom-nav button").forEach(b=>b.classList.toggle("active",b.dataset.screen===s));if(s==="home")renderHome();if(s==="staff")renderStaff();if(s==="reports")renderReports();if(s==="history")renderHistory();if(s==="more")renderMore()}
document.querySelectorAll(".bottom-nav button").forEach(b=>b.onclick=()=>setScreen(b.dataset.screen));
document.getElementById("menuBtn").onclick=()=>setScreen("more");
document.getElementById("bellBtn").onclick=()=>toast("Mr Relax app is ready");

function renderHome(){
 const work=db.entries.reduce((a,e)=>a+e.work,0), exp=db.entries.reduce((a,e)=>a+e.expense,0), share=db.entries.reduce((a,e)=>a+e.share,0);
 document.getElementById("screen").innerHTML=`<div class="datebar"><b>📅 ${fmt(today())}</b><span>⌄</span></div>
 <div class="card"><div class="section-title">Today's Summary</div><div class="stats">
 <div class="stat"><div class="label">TOTAL WORK</div><div class="value">${money(db.entries.filter(e=>e.date===today()).reduce((a,e)=>a+e.work,0))}</div></div>
 <div class="stat"><div class="label">50% STAFF SHARE</div><div class="value">${money(db.entries.filter(e=>e.date===today()).reduce((a,e)=>a+e.share,0))}</div></div>
 <div class="stat"><div class="label">TODAY'S EXPENSE</div><div class="value">${money(db.entries.filter(e=>e.date===today()).reduce((a,e)=>a+e.expense,0))}</div></div>
 <div class="stat"><div class="label">TODAY'S EARNING</div><div class="value green">${money(db.entries.filter(e=>e.date===today()).reduce((a,e)=>a+e.earning,0))}</div></div>
 </div></div>
 <div class="card"><div class="section-title">Staff Pending / Running Total</div>${db.staff.map(s=>`<div class="staff-row" onclick="openStaff(${s.id})"><div class="avatar">${esc(s.name[0]||"X")}</div><div class="staff-info"><b>${esc(s.name)}</b><small>${s.active?"Active":"Inactive"}</small></div><div class="amount">${money(staffBalance(s.id))}</div></div>`).join("")}</div>
 <div class="card"><button class="primary" onclick="openEntry()">＋ Add Daily Entry</button></div>`;
}
function renderStaff(){
 document.getElementById("screen").innerHTML=`<div class="datebar"><b>Staff</b><button class="secondary" onclick="openStaffForm()">＋ Add Staff</button></div>
 <div class="card">${db.staff.map(s=>`<div class="staff-row"><div class="avatar">${esc(s.name[0]||"X")}</div><div class="staff-info" onclick="openStaff(${s.id})"><b>${esc(s.name)}</b><small>${s.active?"Active":"Inactive"} • Pending ${money(staffBalance(s.id))}</small></div><button class="secondary" onclick="openStaffForm(${s.id})">✎</button></div>`).join("")}</div>`;
}
function openStaff(id){
 let s=staffById(id); document.getElementById("screen").innerHTML=`<div class="datebar"><button class="secondary" onclick="setScreen('staff')">← Back</button><b>${esc(s.name)}</b><button class="secondary" onclick="openEntry(${s.id})">＋</button></div>
 <div class="big-total"><small>CURRENT RUNNING TOTAL</small><strong>${money(staffBalance(id))}</strong></div>
 <div class="card"><div class="two"><div><b>Total Work</b><br>${money(staffWork(id))}</div><div><b>50% Share</b><br>${money(staffShare(id))}</div></div><hr><div class="two"><div><b>Expense</b><br>${money(totalExpense(id))}</div><div><b>Cleared</b><br>${money(db.clears.filter(c=>c.staffId==id).reduce((a,c)=>a+c.amount,0))}</div></div></div>
 <div class="card"><button class="primary" onclick="openEntry(${id})">＋ Add Today's Entry</button><br><br><button class="primary" onclick="clearHisab(${id})">💰 HISAAB CLEAR</button></div>
 <div class="card"><div class="section-title">Daily History</div>${db.entries.filter(e=>e.staffId==id).sort((a,b)=>b.date.localeCompare(a.date)).map(e=>`<div class="staff-row"><div class="staff-info"><b>${fmt(e.date)}</b><small>Work ${money(e.work)} • 50% ${money(e.share)} • Expense ${money(e.expense)}</small></div><div class="amount">${money(e.earning)}</div></div>`).join("")||'<div class="empty">No entries yet.</div>'}</div>`;
}
function openEntry(id){
 if(!id) id=db.staff[0]?.id;
 let s=staffById(id);
 showModal(`<h3>Daily Entry — ${esc(s.name)}</h3><div class="form">
 <label>Date</label><input id="eDate" type="date" value="${today()}">
 <label>Total Work (₹)</label><input id="eWork" type="number" min="0" value="0" oninput="calcEntry()">
 <label>50% Staff Share</label><input id="eShare" class="calc" readonly value="₹ 0">
 <label>Today's Expense (₹)</label><input id="eExp" type="number" min="0" value="0" oninput="calcEntry()">
 <label>Today's Earning</label><input id="eEarn" class="calc" readonly value="₹ 0"></div>
 <div class="actions"><button class="secondary" onclick="closeModal()">CANCEL</button><button class="primary" onclick="saveEntry(${id})">SAVE ENTRY</button></div>`);
 calcEntry();
}
function calcEntry(){let w=+document.getElementById("eWork").value||0,e=+document.getElementById("eExp").value||0;document.getElementById("eShare").value=money(w*.5);document.getElementById("eEarn").value=money(Math.max(0,w*.5-e))}
function saveEntry(id){
 let w=+document.getElementById("eWork").value||0,e=+document.getElementById("eExp").value||0,d=document.getElementById("eDate").value||today(),earn=Math.max(0,w*.5-e);
 db.entries.push({id:Date.now(),staffId:id,date:d,work:w,share:w*.5,expense:e,earning:earn});save();closeModal();toast("Entry saved");openStaff(id);
}
function openStaffForm(id){
 let s=id?staffById(id):null;
 showModal(`<h3>${s?"Edit Staff":"Add Staff"}</h3><div class="form"><label>Staff Name</label><input id="sName" value="${esc(s?.name||"")}"><label>Status</label><select id="sActive"><option value="1" ${!s||s.active?"selected":""}>Active</option><option value="0" ${s&&!s.active?"selected":""}>Inactive</option></select></div><div class="actions"><button class="secondary" onclick="closeModal()">CANCEL</button><button class="primary" onclick="saveStaff(${id||0})">SAVE</button></div>`);
}
function saveStaff(id){let name=document.getElementById("sName").value.trim();if(!name)return toast("Name required");if(id){let s=staffById(id);s.name=name;s.active=document.getElementById("sActive").value==="1"}else db.staff.push({id:Date.now(),name,active:true});save();closeModal();renderStaff();toast("Staff saved")}
function clearHisab(id){
 let amount=staffBalance(id); if(amount<=0)return toast("No pending amount");
 showModal(`<h3>Hisaab Clear</h3><div class="big-total"><small>Clear pending hisaab for ${esc(staffById(id).name)}</small><strong>${money(amount)}</strong></div><p>Is amount ko paid/clear mark karna hai?</p><div class="actions"><button class="secondary" onclick="closeModal()">CANCEL</button><button class="primary" onclick="confirmClear(${id},${amount})">CONFIRM</button></div>`);
}
function confirmClear(id,amount){db.clears.push({id:Date.now(),staffId:id,date:today(),amount,clearedBy:"Owner"});save();closeModal();toast("Hisaab cleared");openStaff(id)}
function renderHistory(){
 let rows=db.clears.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(c=>`<tr><td>${fmt(c.date)}</td><td>${esc(staffById(c.staffId)?.name||"Deleted")}</td><td>${money(c.amount)}</td><td>${esc(c.clearedBy)}</td></tr>`).join("");
 document.getElementById("screen").innerHTML=`<div class="datebar"><b>Hisaab History</b></div><div class="card"><div class="table-wrap"><table class="table"><tr><th>Cleared On</th><th>Staff</th><th>Amount</th><th>By</th></tr>${rows||'<tr><td colspan="4" class="empty">No cleared history.</td></tr>'}</table></div><div class="big-total"><small>TOTAL CLEARED</small><strong>${money(db.clears.reduce((a,c)=>a+c.amount,0))}</strong></div></div>`;
}
function renderReports(){
 let rows=db.staff.map(s=>`<tr><td>${esc(s.name)}</td><td>${money(staffWork(s.id))}</td><td>${money(staffShare(s.id))}</td><td>${money(totalExpense(s.id))}</td><td>${money(staffBalance(s.id))}</td></tr>`).join("");
 document.getElementById("screen").innerHTML=`<div class="datebar"><b>Reports</b><span>This Data</span></div><div class="card"><div class="table-wrap"><table class="table"><tr><th>Staff</th><th>Work</th><th>50% Share</th><th>Expense</th><th>Pending</th></tr>${rows}<tr><th>TOTAL</th><th>${money(db.entries.reduce((a,e)=>a+e.work,0))}</th><th>${money(db.entries.reduce((a,e)=>a+e.share,0))}</th><th>${money(db.entries.reduce((a,e)=>a+e.expense,0))}</th><th>${money(db.staff.reduce((a,s)=>a+staffBalance(s.id),0))}</th></tr></table></div></div>`;
}
function renderMore(){
 document.getElementById("screen").innerHTML=`<div class="datebar"><b>More</b></div><div class="card">
 <button class="list-btn" onclick="openStaffForm()"><span>♟ <b>Add Staff</b><small>Add another staff member</small></span>›</button>
 <button class="list-btn" onclick="renderStaff()"><span>✎ <b>Edit Staff</b><small>Change staff names/status</small></span>›</button>
 <button class="list-btn" onclick="exportData()"><span>⇩ <b>Export Data</b><small>Download a backup JSON file</small></span>›</button>
 <button class="list-btn" onclick="document.getElementById('fileInput').click()"><span>⇧ <b>Import Data</b><small>Restore a backup</small></span>›</button>
 <button class="list-btn" onclick="resetData()"><span>⚠ <b>Reset Data</b><small>Delete local app data</small></span>›</button>
 <input id="fileInput" type="file" accept=".json" hidden onchange="importData(this.files[0])">
 </div><div class="card"><b>Mr Relax Men's Parlour</b><p>Daily staff earning manager • 50% share • expense deduction • running pending • hisaab clear history.</p></div>`;
}
function exportData(){let a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(db,null,2)],{type:"application/json"}));a.download="mr_relax_backup.json";a.click();URL.revokeObjectURL(a.href)}
function importData(file){if(!file)return;let r=new FileReader();r.onload=()=>{try{db=JSON.parse(r.result);save();toast("Backup restored");setScreen("home")}catch(e){toast("Invalid backup")}};r.readAsText(file)}
function resetData(){if(confirm("Delete all local app data?")){localStorage.removeItem(KEY);location.reload()}}
function showModal(x){document.getElementById("modalCard").innerHTML=x;document.getElementById("modal").classList.remove("hidden")}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
document.getElementById("modal").onclick=e=>{if(e.target.id==="modal")closeModal()}
setScreen("home");
